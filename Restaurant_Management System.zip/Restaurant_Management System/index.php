<?php
    header("location:views/home.php")
?>