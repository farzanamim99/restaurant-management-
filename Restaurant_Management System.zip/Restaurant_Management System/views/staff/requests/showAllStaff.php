<?php

    include('../../../controls/staff/showAllStaff-controller.php');

    $output =  $userQuery;
    echo $output;


?>


