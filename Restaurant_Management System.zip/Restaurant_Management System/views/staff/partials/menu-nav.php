<nav class="navbar">
    <ul>
        <li><a href="inventory.php" id="view-items">Go back to previous page</a></li>
    </ul> 
</nav>