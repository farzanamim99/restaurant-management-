<!-- Pre-loader -->
<section id="loader-container">
    <div class="loader"></div>
</section>
