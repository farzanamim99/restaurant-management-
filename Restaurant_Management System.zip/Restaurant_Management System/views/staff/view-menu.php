<?php
    include('partials/header.php');
    include('partials/menu-nav.php');
    include('partials/preloader.php');

?>



<?php include('partials/footer.php'); 


?>