<?php
    session_start();
    include('./header.php'); 
    include("./nav.php"); 
    include("../../models/customer/db.php");
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>
<div class="view">
    <form action="" method="post">
    <h2>View Customers </h2>
    <br>
    <br>
    <table>
        <tr>
            <th>Customer ID </th>
            <th>Full Name</th> 
            <th>Email</th> 
            <th>Gender</th> 
        </tr>
        <tr> <?php
            $connection = new db();
            $connObj = $connection->openConn();
            $userQuery = $connection->allCustomer($connObj,"customer");
            $connection->closeConn($connObj); ?>
        </tr>
    </table>
</div>
</center>