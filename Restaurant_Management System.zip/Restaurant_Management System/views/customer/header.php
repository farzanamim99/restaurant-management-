<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../public/customer/stylesheets/styles.css?v=<?= time(); ?>" type="text/css">
    <title>Customer @Akhirul</title>
</head>
<body>