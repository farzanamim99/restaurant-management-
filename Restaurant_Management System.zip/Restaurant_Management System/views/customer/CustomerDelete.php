<?php 
    include('./header.php');
    include('../../controls/customer/DeleteValidation.php'); 
    include("./nav.php"); 
?>
<center>
<div class="delete">
<form action="" method="post">
    <br>
    <h2>Do you want to delete your profile ?</h2>
    <br>
    <br>
    <br>
    <input type="password" name="pass" id="pass" placeholder="To delete enter password" class="delete-inp">
    <br>
    <br>
    <input type="submit" name="dlt" value="Delete" id="btn">
</form>
</div>
</center>