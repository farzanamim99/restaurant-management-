<?php
session_start(); 
if(empty($_SESSION["username"])) {
    header("Location: ../control/login.php"); // Redirecting To Home Page
}

include('../../models/supplier/db.php');
$connection = new db();
$conobj=$connection->OpenCon();
$userQuery=$connection->ShowAllProduct($conobj,"supplier");
// echo $userQuery->num_rows;


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Suppliers</title>
</head>
<body>

  <?php

  if ($userQuery->num_rows > 0) {

    // output data of each row
    while($row = $userQuery->fetch_assoc()) {
      $uname=$row["username"];
      $pword=$row["password"];
      $fname=$row["firstname"];
      $femail = $row["email"];
      $faddress = $row["address"];
      $fdob = $row["dob"];
      $fgender = $row["gender"];
      $fSupplyItem = $row["SupplyItem"];
      $fInterests = $row["interest"];
     

      
      echo "<br/>".$uname;
      echo "<br/>".$pword;
      echo "<br/>".$fname;
      echo "<br/>".$femail;
      echo "<br/>".$faddress;
      echo "<br/>".$fdob;
      echo "<br/>".$fgender;
      echo "<br/>".$fSupplyItem;
      echo "<br/>".$fInterests;
      echo "<br/><br/>";

    }

    }
  else {
    echo "0 results";
  }


 

  ?>
    
</body>
</html>